import os
import cv2
import numpy as np

def is_image(file):
    is_image = False
    file_ext = file.split(".")[-1]
    
    if (file_ext.lower() == "jpg") or (file_ext.lower() == "jpeg") or(file_ext.lower() == "png") or (file_ext.lower() == "bmp"):
        is_image = True
    
    return is_image

def get_image_list(data_root):
    total_files = list()
    imgs = list()
    
    for dirpath,_,filenames in os.walk(data_root):
        total_files += [dirpath.replace("\\","/")+"/"+file for file in filenames]

    for file in total_files:
        if is_image(file):
            imgs.append(file)
        else:
            continue
            
    return imgs

def main(data_root):
    img_list = get_image_list(data_root)

    color_list = [(255,255,0),(255,0,255),(0,255,255)]

    for img_path in img_list:
        image = cv2.imread(img_path)
        mask_path = img_path.replace(img_path.split(".")[-1],"")+"mask"
        mask = cv2.imread(mask_path)

        mask = mask[:,:,0]

        image = image*.7
        image = image.astype('uint8')
        height,width,_ = image.shape

        total_mask = cv2.merge([np.zeros((height,width),dtype='uint8'),np.zeros((height,width),dtype='uint8'),np.zeros((height,width),dtype='uint8')])
        
        for id in range(3):
            color = color_list[id]
            id = id+1

            id_mask = mask.copy()

            id_mask[id_mask!=id] = 0
            id_mask[id_mask==id] = 1

            r = id_mask*color[0]
            g = id_mask*color[1]
            b = id_mask*color[2]

            id_mask = cv2.merge([r,g,b])*.3
            id_mask = id_mask.astype('uint8')

            total_mask += id_mask
        
        image = image+total_mask
                
        cv2.imshow("mask",image)
        cv2.waitKey(0)

if __name__ == '__main__':
    data_root = "sequence_01" # "sequence_02"
    main(data_root)